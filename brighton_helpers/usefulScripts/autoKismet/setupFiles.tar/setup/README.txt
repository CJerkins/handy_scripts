This process will enable a configurable kismet conf file, and install gpsd (allow gps tagging) and gpsprune (offline mapping software).
Move the contents of this package to /home -- this will be your workspace. 

Set-up-
1. Connect Pi to Internet to pull updates and new depends
2. Run the install.sh script from the setup directory (sudo ./install.sh)
3a. Plug the GPS puck into the pi and run "sudo dmesg"
3b. Identify in the dmesg output where the GPS puck has been parked (e.g. /dev/ttyUSB0)
3c. Run 'sudo gpsd /dev/ttyUSB0' (or whatever output was provided above in step 3b.
4. Run 'crontab -e', select 1 for nano, and paste the following into a new line on the bottom: @reboot sleep 20 && kismet



Post-op-
KML
sudo kismetdb_to_kml --in <kismetFile> --out <outputName.kml>
	Then you can run gpsprun <outputName.kml>

PCAP
sudo kismetdb_to_pcap --in <kismetFile> --out <outputName.pcap>
