#!/bin/bash

#Usage: connect pi to internet and  run this script (sudo ./setup.sh)

#Install depends
sudo apt update
sudo apt install airgraph-ng gpsd gpsprune -y

sleep 1

#Build output directory to user's home desktop
mkdir /home/kismetFiles
chown kali /home/kismetFiles
cp kismet_site.conf /etc/kismet/


#Allow user to run without root

sudo usermod -aG kismet kali

#print Read Me
cat README.txt
